package ProjekAkhirPendidikan;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class HalamanAdmin extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel namaSiswa;
    private DefaultTableModel NilaiSiswa;
    private DefaultTableModel hasilSiswa;
    public HalamanAdmin() {
        initComponents();
        
        conn = Koneksi.getConnection();
        
        namaSiswa = new DefaultTableModel();
        tblSiswa.setModel(namaSiswa);
        namaSiswa.addColumn("NISN");
        namaSiswa.addColumn("Nama");
        namaSiswa.addColumn("Kelas");       
        loadDataNamaSiswa();
        
        NilaiSiswa = new DefaultTableModel();
        tblNilai.setModel(NilaiSiswa);
        NilaiSiswa.addColumn("NISN");
        NilaiSiswa.addColumn("Mata Pelajaran");
        NilaiSiswa.addColumn("Tugas Harian");
        NilaiSiswa.addColumn("UTS");
        NilaiSiswa.addColumn("UAS");
        loadDataNilaiSiswa(); 
        
        hasilSiswa = new DefaultTableModel();
        tblHasil.setModel(hasilSiswa);
        hasilSiswa.addColumn("NISN");
        hasilSiswa.addColumn("Nama");
        hasilSiswa.addColumn("Kelas"); 
        hasilSiswa.addColumn("MataPelajaran"); 
        hasilSiswa.addColumn("Tugas Harian"); 
        hasilSiswa.addColumn("UTS");
        hasilSiswa.addColumn("UAS"); 
        hasilSiswa.addColumn("Rata Rata"); 
        hasilSiswa.addColumn("Status");
    }

    private void loadDataNamaSiswa() {
        namaSiswa.setRowCount(0);
        try {
            String sql = "SELECT * FROM Siswa";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                namaSiswa.addRow(new Object[]{
                    rs.getInt("NISN"),
                    rs.getString("Nama"),
                    rs.getString("Kelas")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }

    private void loadDataNilaiSiswa() {
          NilaiSiswa.setRowCount(0);
          try {
              String sql = "SELECT * FROM Nilai ";
              PreparedStatement ps = conn.prepareStatement(sql);
              ResultSet rs = ps.executeQuery();
              while (rs.next()) {
                 NilaiSiswa.addRow(new Object[]{
                 rs.getInt("id_nisn"),
                 rs.getString("mapel"),
                 rs.getInt("harian"),
                 rs.getInt("uts"),
                 rs.getInt("uas"),
                 rs.getInt("rata_rata"),
                 rs.getInt("keterangan"),
             });
              }
          } catch (SQLException e) {
             System.out.println("Error Save Data" + e.getMessage());
           }          
        }
        
    private void clearDataSiswa() {
            tfNISN.setText("");
            tfNamaSiswa.setText("");
            tfKelas.setText("");
        }
        private void clearNilaiSiswa() {
            tf_NISN.setText("");
            tfTUGAS.setText("");
            tfUTS.setText("");
            tfUAS.setText("");
        }
        
        private void saveDataSiswa() {
        if (tfNISN.getText().trim().isEmpty() || 
            tfNamaSiswa.getText().trim().isEmpty() || 
            tfKelas.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            String sql = "INSERT INTO siswa (NISN, nama, kelas) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(tfNISN.getText()));
            ps.setString(2, tfNamaSiswa.getText());
            ps.setString(3, tfKelas.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Siswa Berhasil Disimpan");
            loadDataNamaSiswa(); // Fungsi untuk memuat ulang data siswa ke dalam tabel
            clearDataSiswa();    // Fungsi untuk mengosongkan field input
            ps.close();
        } catch (NumberFormatException e) {
        // Tampilkan pesan jika NISN bukan angka
            JOptionPane.showMessageDialog(this, "NISN harus berupa angka.", "Peringatan", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data siswa: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } private void saveNilaiSiswa() {
         if (tfTUGAS.getText().trim().isEmpty() || 
             tfUTS.getText().trim().isEmpty() || 
             tfUAS.getText().trim().isEmpty()) {
             JOptionPane.showMessageDialog(this, "Semua field harus diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
             return;
         }
         if (conn == null) {
             JOptionPane.showMessageDialog(this, "Koneksi database belum tersedia.", "Error", JOptionPane.ERROR_MESSAGE);
             return;
         }
         try {
             // Mengambil nilai dari field input
             int harian = Integer.parseInt(tfTUGAS.getText());
             int uts = Integer.parseInt(tfUTS.getText());
             int uas = Integer.parseInt(tfUAS.getText());

             // Menghitung rata-rata
             double rataRata = (harian + uts + uas) / 3.0;

             // Menentukan keterangan berdasarkan rata-rata
             String keterangan;
             if (rataRata >= 75) {
                 keterangan = "Lulus";
             } else {
                 keterangan = "Tidak Lulus";
             }

             // Query untuk menyimpan data termasuk kolom baru
             String sql = "INSERT INTO nilai (id_nisn, mapel, harian, UTS, UAS, rata_rata, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?)";
             PreparedStatement ps = conn.prepareStatement(sql);
             ps.setInt(1, Integer.parseInt(tf_NISN.getText())); // Ambil NISN
             ps.setString(2, cbMapel.getSelectedItem().toString()); // Ambil mapel dari JComboBox
             ps.setInt(3, harian);
             ps.setInt(4, uts);
             ps.setInt(5, uas);
             ps.setDouble(6, rataRata); // Set nilai rata-rata
             ps.setString(7, keterangan); // Set keterangan

             int rowsAffected = ps.executeUpdate();
             if (rowsAffected > 0) {
                 JOptionPane.showMessageDialog(this, "Data Nilai Berhasil Disimpan");
                 loadDataNilaiSiswa(); // Memuat ulang data nilai
                 clearNilaiSiswa();    // Mengosongkan field input
             } else {
                 JOptionPane.showMessageDialog(this, "Tidak ada data yang disimpan.", "Error", JOptionPane.ERROR_MESSAGE);
             }
             ps.close();
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(this, "Error Save Data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
         } catch (NumberFormatException e) {
             JOptionPane.showMessageDialog(this, "Pastikan semua field nilai berisi angka yang valid.", "Error", JOptionPane.ERROR_MESSAGE);
         }
     }
    private void deleteDataSiswa() {
       try {
           // Validasi input NISN
           String nisnText = tfNISN.getText();
           if (nisnText.isEmpty()) {
               JOptionPane.showMessageDialog(this, "NISN tidak boleh kosong", "Validation Error", JOptionPane.WARNING_MESSAGE);
               return;
           }

           int nisn = Integer.parseInt(nisnText);

           // Menghapus data terkait di tabel 'nilai' terlebih dahulu
           String deleteNilaiSql = "DELETE FROM nilai WHERE id_nisn = ?";
           PreparedStatement psNilai = conn.prepareStatement(deleteNilaiSql);
           psNilai.setInt(1, nisn);
           int nilaiRowsAffected = psNilai.executeUpdate();
           NilaiSiswa.setRowCount(0);

           if (nilaiRowsAffected > 0) {
               System.out.println("Data nilai untuk NISN " + nisn + " berhasil dihapus.");
           } else {
               System.out.println("Tidak ada data nilai ditemukan untuk NISN " + nisn);
           }

           // Menghapus data dari tabel siswa
           String deleteSiswaSql = "DELETE FROM siswa WHERE NISN = ?";
           PreparedStatement psSiswa = conn.prepareStatement(deleteSiswaSql);
           psSiswa.setInt(1, nisn);

           int rowsAffected = psSiswa.executeUpdate();
           if (rowsAffected > 0) {
               JOptionPane.showMessageDialog(this, "Data berhasil dihapus");
               loadDataNamaSiswa();  // Reload data nama siswa jika diperlukan
               clearDataSiswa();  // Kosongkan form setelah penghapusan
           } else {
               JOptionPane.showMessageDialog(this, "Data tidak ditemukan.", "Delete Error", JOptionPane.ERROR_MESSAGE);
           }
       } catch (NumberFormatException e) {
           JOptionPane.showMessageDialog(this, "NISN harus berupa angka yang valid.", "Input Error", JOptionPane.ERROR_MESSAGE);
       } catch (SQLException e) {
           System.err.println("SQL Error: " + e.getMessage());
           JOptionPane.showMessageDialog(this, "Kesalahan saat menghapus data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
       }
   }

    private void updateDataSiswa() {
            try {
                String sql = "UPDATE siswa SET nama = ?, kelas = ? WHERE NISN = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, tfNamaSiswa.getText());
                ps.setString(2, tfKelas.getText());
                ps.setInt(3, Integer.parseInt(tfNISN.getText()));

                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Data berhasil di diperbarui");
                    loadDataNamaSiswa();
                    clearDataSiswa();
                } else {
                    JOptionPane.showMessageDialog(this, "Data tidak ditemukan .", "Update Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Kesalahan saat memperbarui data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    private void updateNilaiSiswa() {
    // Cek jika ada field yang kosong
    if (tfTUGAS.getText().trim().isEmpty() || 
        tfUTS.getText().trim().isEmpty() || 
        tfUAS.getText().trim().isEmpty() || 
        tf_NISN.getText().trim().isEmpty() || 
        cbMapel.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(this, "Semua field harus diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
        return;  // Hentikan eksekusi jika ada yang kosong
    }

    // Cek apakah koneksi database tersedia
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "Koneksi database belum tersedia.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Mengambil nilai dari field input dengan pengecekan validasi angka
        int harian = validateAndParseInt(tfTUGAS.getText());
        int uts = validateAndParseInt(tfUTS.getText());
        int uas = validateAndParseInt(tfUAS.getText());

        // Menghitung rata-rata
        double rataRata = (harian + uts + uas) / 3.0;

        // Menentukan keterangan berdasarkan rata-rata
        String keterangan = (rataRata >= 75) ? "Lulus" : "Tidak Lulus";

        // Query untuk update data nilai
        String sql = "UPDATE nilai SET harian = ?, UTS = ?, UAS = ?, rata_rata = ?, keterangan = ? WHERE id_nisn = ? AND mapel = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        
        // Set parameter untuk query update
        ps.setInt(1, harian);
        ps.setInt(2, uts);
        ps.setInt(3, uas);
        ps.setDouble(4, rataRata);
        ps.setString(5, keterangan);
        ps.setInt(6, Integer.parseInt(tf_NISN.getText()));  // Mengambil NISN
        ps.setString(7, cbMapel.getSelectedItem().toString());  // Mengambil mata pelajaran dari ComboBox

        // Eksekusi query update
        int rowsAffected = ps.executeUpdate();
        
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Data Nilai Berhasil Diperbarui");
            loadDataNilaiSiswa();  // Memuat ulang data nilai
            clearNilaiSiswa();     // Mengosongkan field input
        } else {
            JOptionPane.showMessageDialog(this, "Tidak ada data yang diperbarui.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        ps.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Update Data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Fungsi untuk memvalidasi dan mengonversi input menjadi integer
private int validateAndParseInt(String input) {
    try {
        return Integer.parseInt(input);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Pastikan nilai yang dimasukkan adalah angka valid.", "Error", JOptionPane.ERROR_MESSAGE);
        throw e; // Menyebarkan exception untuk menghentikan eksekusi lebih lanjut
    }
}






 private void cariDataSiswa() {
     hasilSiswa.setRowCount(0);
    String nisn = tfCari.getText().trim();
    if (nisn.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Mohon masukkan NISN untuk pencarian!");
    } else {
        loadDataHasil(nisn);
    }
}

private void loadDataHasil(String nisn) {
    hasilSiswa.setRowCount(0); // Bersihkan data di tabel hasilSiswa
    
    try {
        
        String query = "SELECT siswa.NISN, siswa.Nama, siswa.kelas, nilai.mapel, nilai.harian AS `Tugas Harian`, nilai.UTS, nilai.UAS " +
                       "FROM siswa JOIN nilai ON siswa.NISN = nilai.id_nisn WHERE siswa.NISN = ?";

        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, nisn); // Set parameter NISN

        ResultSet rs = pstmt.executeQuery();
        
        // Cek apakah ada data yang ditemukan
        if (rs.next()) {
            do {
                // Ambil nilai Tugas Harian, UTS, dan UAS
                int tugasHarian = rs.getInt("Tugas Harian");
                int uts = rs.getInt("UTS");
                int uas = rs.getInt("UAS");

                // Hitung rata-rata nilai
                double rataRata = (tugasHarian + uts + uas) / 3.0;

                // Tentukan status (Lulus atau Tidak Lulus)
                String status = rataRata >= 75 ? "Lulus" : "Tidak Lulus";

                // Tambahkan data siswa beserta rata-rata dan status ke tabel
                hasilSiswa.addRow(new Object[]{
                    rs.getInt("NISN"),
                    rs.getString("Nama"),
                    rs.getString("kelas"),
                    rs.getString("mapel"),
                    tugasHarian,
                    uts,
                    uas,
                    rataRata,
                    status
                });
            } while (rs.next());
        } else {
            JOptionPane.showMessageDialog(this, "Data siswa dengan NISN tersebut tidak ditemukan!");
        }

        rs.close();
        pstmt.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan dalam pencarian data siswa.");
    }
}

    private void cetakKePDF() {
    // Tampilkan dialog input untuk memasukkan nama file
    String fileName = JOptionPane.showInputDialog(null, "Masukkan nama file PDF:", "Nama File", JOptionPane.PLAIN_MESSAGE);

    // Jika pengguna menekan "Cancel" atau tidak mengisi nama, batalkan proses
    if (fileName == null || fileName.trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Pembuatan PDF dibatalkan.");
        return;
    }

    // Set ekstensi .pdf jika pengguna tidak menambahkannya
    if (!fileName.toLowerCase().endsWith(".pdf")) {
        fileName += ".pdf";
    }

    // Periksa apakah tabel hasilSiswa kosong
    if (hasilSiswa.getRowCount() == 0) {
        JOptionPane.showMessageDialog(null, "Laporan kosong, laporan tidak dapat dicetak.");
        return;
    }

    // Tentukan lokasi penyimpanan file PDF
    String filePath = "C:/Users/HP/Documents/" + fileName;

    Document document = new Document(PageSize.A4);

    try {
        PdfWriter.getInstance(document, new FileOutputStream(filePath));
        document.open();

        // Judul PDF
        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph title = new Paragraph("Laporan Hasil Siswa", fontHeader);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph("\n"));

        // Membuat tabel dengan jumlah kolom yang sesuai
        PdfPTable table = new PdfPTable(9); // 9 kolom: NISN, Nama, Kelas, Mata Pelajaran, Tugas Harian, UTS, UAS, Rata-Rata, Status
        table.setWidthPercentage(100);

        // Menambahkan header ke tabel PDF
        String[] header = {"NISN", "Nama", "Kelas", "Mata Pelajaran", "Tugas Harian", "UTS", "UAS", "Rata-Rata", "Status"};
        for (String column : header) {
            PdfPCell cell = new PdfPCell(new Phrase(column, fontHeader));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }

        // Menambahkan data dari tabel hasilSiswa ke tabel PDF
        for (int i = 0; i < hasilSiswa.getRowCount(); i++) {
            Object nisn = hasilSiswa.getValueAt(i, 0);
            Object nama = hasilSiswa.getValueAt(i, 1);
            Object kelas = hasilSiswa.getValueAt(i, 2);
            Object mapel = hasilSiswa.getValueAt(i, 3);
            Object tugasHarianObj = hasilSiswa.getValueAt(i, 4);
            Object utsObj = hasilSiswa.getValueAt(i, 5);
            Object uasObj = hasilSiswa.getValueAt(i, 6);

            if (nisn == null || nama == null || kelas == null || mapel == null || tugasHarianObj == null || utsObj == null || uasObj == null) {
                continue;
            }

            int tugasHarian = (tugasHarianObj instanceof Integer) ? (int) tugasHarianObj : 0;
            int uts = (utsObj instanceof Integer) ? (int) utsObj : 0;
            int uas = (uasObj instanceof Integer) ? (int) uasObj : 0;

            table.addCell(nisn.toString());
            table.addCell(nama.toString());
            table.addCell(kelas.toString());
            table.addCell(mapel.toString());
            table.addCell(String.valueOf(tugasHarian));
            table.addCell(String.valueOf(uts));
            table.addCell(String.valueOf(uas));

            double rataRata = (tugasHarian + uts + uas) / 3.0;
            String status = rataRata >= 75 ? "Lulus" : "Tidak Lulus";

            table.addCell(String.format("%.2f", rataRata));
            table.addCell(status);
        }

        document.add(table); // Tambahkan tabel ke dokumen
        JOptionPane.showMessageDialog(null, "PDF berhasil disimpan di lokasi: " + filePath);

    } catch (DocumentException | IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Gagal menyimpan PDF: " + e.getMessage());
    } finally {
        document.close();
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        m1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        tfNISN = new javax.swing.JTextField();
        tfNamaSiswa = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        tfKelas = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSiswa = new javax.swing.JTable();
        btn_DeleteSiswa = new javax.swing.JButton();
        btn_UpdateSiswa = new javax.swing.JButton();
        btn_simpanData = new javax.swing.JButton();
        m2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        tf_NISN = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cbMapel = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tfUAS = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tfUTS = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tfTUGAS = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblNilai = new javax.swing.JTable();
        btn_UpdateNilai = new javax.swing.JButton();
        btn_SimpanNilai = new javax.swing.JButton();
        m3 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        tfCari = new javax.swing.JTextField();
        btnCari = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblHasil = new javax.swing.JTable();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(102, 102, 255));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("SMA NEGERI1 JEMBER ");

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/LOGOOSMA-removebg-preview.png"))); // NOI18N

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/LOGOOSMA-removebg-preview.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel13)
                .addGap(143, 143, 143)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 144, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addGap(15, 15, 15))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jLabel13)
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 830, 90));

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setText("LogOut");
        jLabel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jLabel1MouseMoved(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(114, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(384, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(40, 40, 40))
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 160, 440));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setBackground(new java.awt.Color(102, 102, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 255));
        jLabel2.setText("NISN ");

        tfNamaSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNamaSiswaActionPerformed(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(102, 102, 255));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 153, 255));
        jLabel4.setText("Nama Siswa");

        tfKelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfKelasActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(102, 102, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 255));
        jLabel5.setText("Kelas");

        tblSiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblSiswa);

        btn_DeleteSiswa.setBackground(new java.awt.Color(204, 0, 0));
        btn_DeleteSiswa.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_DeleteSiswa.setForeground(new java.awt.Color(255, 255, 255));
        btn_DeleteSiswa.setText("Delete");
        btn_DeleteSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DeleteSiswaActionPerformed(evt);
            }
        });

        btn_UpdateSiswa.setBackground(new java.awt.Color(255, 204, 0));
        btn_UpdateSiswa.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_UpdateSiswa.setForeground(new java.awt.Color(255, 255, 255));
        btn_UpdateSiswa.setText("Update");
        btn_UpdateSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_UpdateSiswaActionPerformed(evt);
            }
        });

        btn_simpanData.setBackground(new java.awt.Color(51, 102, 255));
        btn_simpanData.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_simpanData.setForeground(new java.awt.Color(255, 255, 255));
        btn_simpanData.setText("Simpan");
        btn_simpanData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanDataActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btn_UpdateSiswa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_DeleteSiswa))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfNISN, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                            .addComponent(tfNamaSiswa)
                            .addComponent(tfKelas)
                            .addComponent(btn_simpanData, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfNISN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfNamaSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfKelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_simpanData))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_DeleteSiswa)
                    .addComponent(btn_UpdateSiswa))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout m1Layout = new javax.swing.GroupLayout(m1);
        m1.setLayout(m1Layout);
        m1Layout.setHorizontalGroup(
            m1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        m1Layout.setVerticalGroup(
            m1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Data Siswa", m1);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setBackground(new java.awt.Color(102, 102, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 153, 255));
        jLabel7.setText("NISN ");

        cbMapel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cbMapel.setForeground(new java.awt.Color(153, 153, 255));
        cbMapel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Mata Pelajaran", "Bahasa Indonesia", "Matematika", "IPA", "Bahasa Inggris" }));

        jLabel8.setBackground(new java.awt.Color(102, 102, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 153, 255));
        jLabel8.setText("Mata Pelajaran");

        jLabel9.setBackground(new java.awt.Color(102, 102, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 153, 255));
        jLabel9.setText("UAS");

        tfUAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfUASActionPerformed(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(102, 102, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 153, 255));
        jLabel10.setText("UTS");

        tfUTS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfUTSActionPerformed(evt);
            }
        });

        jLabel11.setBackground(new java.awt.Color(102, 102, 255));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(153, 153, 255));
        jLabel11.setText("Tugas Harian");

        tfTUGAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTUGASActionPerformed(evt);
            }
        });

        tblNilai.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "NISN", "Mata Pelajaran", "Tugas Harian", "UTS", "UAS"
            }
        ));
        jScrollPane2.setViewportView(tblNilai);

        btn_UpdateNilai.setBackground(new java.awt.Color(255, 204, 0));
        btn_UpdateNilai.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_UpdateNilai.setForeground(new java.awt.Color(255, 255, 255));
        btn_UpdateNilai.setText("Update");
        btn_UpdateNilai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_UpdateNilaiActionPerformed(evt);
            }
        });

        btn_SimpanNilai.setBackground(new java.awt.Color(51, 102, 255));
        btn_SimpanNilai.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_SimpanNilai.setForeground(new java.awt.Color(255, 255, 255));
        btn_SimpanNilai.setText("Simpan");
        btn_SimpanNilai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SimpanNilaiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbMapel, 0, 160, Short.MAX_VALUE)
                            .addComponent(tfTUGAS)
                            .addComponent(tfUTS)
                            .addComponent(tfUAS)
                            .addComponent(tf_NISN)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(btn_SimpanNilai)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_UpdateNilai)
                        .addGap(15, 15, 15))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf_NISN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbMapel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfTUGAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfUTS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfUAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_SimpanNilai))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_UpdateNilai)))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout m2Layout = new javax.swing.GroupLayout(m2);
        m2.setLayout(m2Layout);
        m2Layout.setHorizontalGroup(
            m2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(m2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        m2Layout.setVerticalGroup(
            m2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Nilai Siswa", m2);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setBackground(new java.awt.Color(102, 102, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 255));
        jLabel6.setText("Silahkan Cari NISN Siswa");

        btnCari.setBackground(new java.awt.Color(51, 102, 255));
        btnCari.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari.setForeground(new java.awt.Color(255, 255, 255));
        btnCari.setText("Cari NISN");
        btnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCariActionPerformed(evt);
            }
        });

        tblHasil.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tblHasil);

        jButton8.setBackground(new java.awt.Color(51, 51, 255));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Cetak Ke PDF");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButton8)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(tfCari, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCari))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCari))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout m3Layout = new javax.swing.GroupLayout(m3);
        m3.setLayout(m3Layout);
        m3Layout.setHorizontalGroup(
            m3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(m3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );
        m3Layout.setVerticalGroup(
            m3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(m3Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Laporan Hasil Belajar", m3);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 660, 370));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tfNamaSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNamaSiswaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfNamaSiswaActionPerformed

    private void tfKelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfKelasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfKelasActionPerformed

    private void tfUASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfUASActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfUASActionPerformed

    private void tfUTSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfUTSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfUTSActionPerformed

    private void tfTUGASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTUGASActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTUGASActionPerformed

    private void btn_SimpanNilaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SimpanNilaiActionPerformed
        saveNilaiSiswa();       
    }//GEN-LAST:event_btn_SimpanNilaiActionPerformed

    private void btn_UpdateNilaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_UpdateNilaiActionPerformed
        updateNilaiSiswa();       
    }//GEN-LAST:event_btn_UpdateNilaiActionPerformed

    private void btn_simpanDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanDataActionPerformed
        saveDataSiswa();  
    }//GEN-LAST:event_btn_simpanDataActionPerformed

    private void btn_DeleteSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DeleteSiswaActionPerformed
        deleteDataSiswa();         
    }//GEN-LAST:event_btn_DeleteSiswaActionPerformed

    private void btn_UpdateSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_UpdateSiswaActionPerformed
        updateDataSiswa();        
    }//GEN-LAST:event_btn_UpdateSiswaActionPerformed

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
         cariDataSiswa();
    }//GEN-LAST:event_btnCariActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
         cetakKePDF();        
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jLabel1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseMoved

    }//GEN-LAST:event_jLabel1MouseMoved

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HalamanAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HalamanAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HalamanAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HalamanAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HalamanAdmin().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCari;
    private javax.swing.JButton btn_DeleteSiswa;
    private javax.swing.JButton btn_SimpanNilai;
    private javax.swing.JButton btn_UpdateNilai;
    private javax.swing.JButton btn_UpdateSiswa;
    private javax.swing.JButton btn_simpanData;
    private javax.swing.JComboBox<String> cbMapel;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel m1;
    private javax.swing.JPanel m2;
    private javax.swing.JPanel m3;
    private javax.swing.JTable tblHasil;
    private javax.swing.JTable tblNilai;
    private javax.swing.JTable tblSiswa;
    private javax.swing.JTextField tfCari;
    private javax.swing.JTextField tfKelas;
    private javax.swing.JTextField tfNISN;
    private javax.swing.JTextField tfNamaSiswa;
    private javax.swing.JTextField tfTUGAS;
    private javax.swing.JTextField tfUAS;
    private javax.swing.JTextField tfUTS;
    private javax.swing.JTextField tf_NISN;
    // End of variables declaration//GEN-END:variables
}
